
#!/usr/bin/env bash
# Script semplice per avviare la dashboard in ambiente Unix-like
python -m src.dashboard
