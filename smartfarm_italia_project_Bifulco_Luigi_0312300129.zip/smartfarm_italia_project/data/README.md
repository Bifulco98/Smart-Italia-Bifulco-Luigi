Cartella dedicata ai dati del progetto (input, output, dati simulati).
